ALTER TABLE public.periodos ADD COLUMN activo boolean NOT NULL DEFAULT true;
